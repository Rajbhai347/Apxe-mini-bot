import os from "os";
import config from "../config.js";
import { Module } from "../lib/plugins.js";

const runtime = (secs) => {
  const pad = (s) => String(s).padStart(2, "0");
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  const s = Math.floor(secs % 60);
  return `${pad(h)}h ${pad(m)}m ${pad(s)}s`;
};

// ── Bold font (𝗔𝗕𝗖 / 𝗮𝗯𝗰 / 𝟭𝟮𝟯) ─────────────────────────────────────────────
const bold = (text) =>
  String(text).replace(/[A-Za-z0-9]/g, (c) => {
    const code = c.codePointAt(0);
    if (code >= 65 && code <= 90) return String.fromCodePoint(0x1d5d4 + code - 65);
    if (code >= 97 && code <= 122) return String.fromCodePoint(0x1d5ee + code - 97);
    return String.fromCodePoint(0x1d7ec + code - 48);
  });

// ── Menu data: category → commands (each with its own emoji) ─────────────────
const CATEGORIES = [
  {
    key: "owner",
    command: "ownermenu",
    aliases: [],
    emoji: "👑",
    title: "OWNER MENU",
    cmds: [
      ["anticall", "📵"],
      ["antilink", "🔗"],
      ["sudo", "🛡️"],
      ["delsudo", "🚫"],
      ["sudolist", "📋"],
      ["autoreact", "😍"],
      ["autoread", "👀"],
      ["autorecord", "🎙️"],
      ["autostatus", "📺"],
      ["autotyping", "⌨️"],
      ["block", "⛔"],
      ["blocklist", "📛"],
      ["broadcast", "📢"],
      ["delete", "🗑️"],
      ["delme", "🧹"],
      ["forward", "📤"],
      ["fullpp", "🖼️"],
      ["fwd", "⏩"],
      ["getbio", "📝"],
      ["getname", "🏷️"],
      ["getpp", "📸"],
      ["jid", "🆔"],
      ["join", "➕"],
      ["leaveall", "🚪"],
      ["listgc", "📑"],
      ["mention", "🔔"],
      ["mode", "⚙️"],
      ["myname", "🪪"],
      ["myprivacy", "🔒"],
      ["mystatus", "💬"],
      ["owner", "👑"],
      ["private", "🔐"],
      ["public", "🌍"],
      ["prefix", "🔣"],
      ["quoted", "💭"],
      ["removepp", "❌"],
      ["save", "💾"],
      ["saved", "📥"],
      ["setpp", "🎨"],
      ["setbio", "✍️"],
      ["setname", "📛"],
      ["unblock", "✅"],
      ["unblockall", "🔓"],
    ],
  },
  {
    key: "anime",
    command: "animemenu",
    aliases: [],
    emoji: "🎭",
    title: "ANIME MENU",
    cmds: [
      ["achar", "🧑‍🎤"],
      ["aquotie", "💬"],
      ["arecommend", "⭐"],
      ["asearch", "🔍"],
      ["loli", "🌸"],
      ["maid", "🎀"],
      ["megumin", "💥"],
      ["neko", "🐱"],
      ["shinobu", "🦋"],
      ["waifu", "💖"],
    ],
  },
  {
    key: "convert",
    command: "convertmenu",
    aliases: [],
    emoji: "♻️",
    title: "CONVERT MENU",
    cmds: [
      ["url", "🔗"],
    ],
  },
  {
    key: "download",
    command: "downloadmenu",
    aliases: ["dlmenu"],
    emoji: "⏬",
    title: "DOWNLOAD MENU",
    cmds: [
      ["apk", "📦"],
      ["fb", "📘"],
      ["git", "🐙"],
      ["gitclone", "🧬"],
      ["insta", "📷"],
      ["song", "🎵"],
      ["play", "▶️"],
      ["ytmp3", "🎧"],
      ["yta", "🎶"],
      ["pint", "📌"],
      ["mega", "☁️"],
    ],
  },
  {
    key: "general",
    command: "generalmenu",
    aliases: [],
    emoji: "⚙️",
    title: "GENERAL MENU",
    cmds: [
      ["alive", "💚"],
      ["pair", "🔑"],
      ["gmenu", "👥"],
      ["list", "📜"],
      ["menu", "📖"],
    ],
  },
  {
    key: "group",
    command: "groupmenu",
    aliases: [],
    emoji: "👥",
    title: "GROUP MENU",
    cmds: [
      ["add", "➕"],
      ["admin", "🛡️"],
      ["announce", "📣"],
      ["approve", "✅"],
      ["close", "🔒"],
      ["demote", "⬇️"],
      ["desc", "📝"],
      ["disappear", "⏳"],
      ["fullgcpp", "🖼️"],
      ["getgcpp", "📸"],
      ["goodbye", "👋"],
      ["groupinfo", "ℹ️"],
      ["groupstatus", "📊"],
      ["hidetag", "🫥"],
      ["invite", "💌"],
      ["inviteuser", "📩"],
      ["kick", "🦵"],
      ["kickall", "💣"],
      ["leave", "🚪"],
      ["lock", "🔐"],
      ["open", "🔓"],
      ["poll", "🗳️"],
      ["promote", "⬆️"],
      ["reject", "🚷"],
      ["requests", "📨"],
      ["revoke", "♻️"],
      ["rtag", "🏷️"],
      ["setgpp", "🎨"],
      ["subject", "✏️"],
      ["setwelcome", "🎉"],
      ["setgoodbye", "🥀"],
      ["setmention", "🔔"],
      ["delmention", "🔕"],
      ["tagall", "📣"],
      ["totag", "📍"],
      ["unlock", "🗝️"],
      ["welcome", "🤝"],
    ],
  },
  {
    key: "info",
    command: "infomenu",
    aliases: [],
    emoji: "🔎",
    title: "INFO MENU",
    cmds: [
      ["antimention", "🚨"],
      ["csong", "🎼"],
      ["lyrics", "🎤"],
      ["manga", "📚"],
      ["weather", "⛅"],
    ],
  },
  {
    key: "media",
    command: "mediamenu",
    aliases: [],
    emoji: "📂",
    title: "MEDIA MENU",
    cmds: [
      ["imagehelp", "🆘"],
      ["imageinfo", "🔎"],
      ["remini", "✨"],
      ["s", "🎭"],
      ["sticker", "🧩"],
      ["sticker2image", "🖼️"],
      ["take", "🏷️"],
      ["toimage", "📷"],
      ["video2image", "🎞️"],
      ["vs", "🎬"],
    ],
  },
  {
    key: "misc",
    command: "miscmenu",
    aliases: [],
    emoji: "👾",
    title: "MISC MENU",
    cmds: [
      ["btpn", "🌀"],
      ["ping", "🏓"],
      ["trt", "🌐"],
      ["uptime", "⏰"],
      ["ckid", "🆔"],
    ],
  },
  {
    key: "search",
    command: "searchmenu",
    aliases: [],
    emoji: "🌐",
    title: "SEARCH MENU",
    cmds: [
      ["wiki", "📖"],
      ["yts", "▶️"],
    ],
  },
  {
    key: "tools",
    command: "toolsmenu",
    aliases: [],
    emoji: "🔩",
    title: "TOOLS MENU",
    cmds: [
      ["calc", "🧮"],
      ["circle", "⭕"],
      ["get", "📥"],
      ["qr", "📱"],
      ["shorturl", "✂️"],
      ["ssweb", "📸"],
      ["tomp3", "🎵"],
    ],
  },
  {
    key: "utility",
    command: "utilitymenu",
    aliases: [],
    emoji: "✨",
    title: "UTILITY MENU",
    cmds: [
      ["tts", "🗣️"],
    ],
  },
  {
    key: "viewonce",
    command: "viewoncemenu",
    aliases: ["vomenu"],
    emoji: "👁️",
    title: "VIEW ONCE MENU",
    cmds: [
      ["😂", "😂"],
      ["😃", "😃"],
      ["vv", "👁️"],
      ["vv2", "👀"],
    ],
  },
];

const P = () => config.PREFIX || config.prefix || ".";
const LINE = "▰▱▰▱▰▱▰▱▰▱▰▱▰▱▰▱";
const BRAND = "𝐃𝐇--𝐊 𝐗 𝐌𝐃";

// ── Main menu (shows only menu names) ───────────────────────────────────────
const mainMenu = (message) => {
  const p = P();
  const used = ((os.totalmem() - os.freemem()) / 1073741824).toFixed(2);
  const total = (os.totalmem() / 1073741824).toFixed(2);

  const list = CATEGORIES.map(
    (c, i) =>
      `┃ ${c.emoji} *${bold(c.title)}*\n┃    ┗━➤ \`${p}${c.command}\` ⟨${c.cmds.length}⟩`
  ).join("\n┃\n");

  return `╔═══════════════════╗
   ✦ *${BRAND}* ✦
╚═══════════════════╝

╭━━━〔 📡 *${bold("SYSTEM INFO")}* 〕━━━⊷
┃ 👑 *${bold("Owner")}* ➜ ⦏𝐍𝐎 𝐋𝐎𝐕𝐄⦐
┃ 📦 *${bold("Version")}* ➜ 3.0.0
┃ 📱 *${bold("Mode")}* ➜ PUBLIC
┃ ⏰ *${bold("Uptime")}* ➜ ${runtime(process.uptime())}
┃ 💾 *${bold("Space")}* ➜ ${used} / ${total} GB
┃ 🙍🏻 *${bold("User")}* ➜ ${message.pushName || "User"}
╰━━━━━━━━━━━━━━━━━━━⊷

${LINE}
 🔥 *${bold("SELECT A MENU")}* 🔥
${LINE}

╭━━━〔 📜 *${bold("ALL MENUS")}* 〕━━━⊷
┃
${list}
┃
╰━━━━━━━━━━━━━━━━━━━⊷

💡 *${bold("Tip")}* ➜ ${bold("Type a menu name")}, ${bold("e.g.")} \`${p}ownermenu\`
📖 ${bold("All commands at once")} ➜ \`${p}allmenu\`

> ${BRAND}`;
};

// ── Single category menu ────────────────────────────────────────────────────
const categoryMenu = (cat) => {
  const p = P();
  const rows = cat.cmds
    .map(([name, emoji]) => `┃ ${emoji} *${bold(name.toUpperCase())}*`)
    .join("\n");

  return `╔═══════════════════╗
  ${cat.emoji} *${bold(cat.title)}* ${cat.emoji}
╚═══════════════════╝

${LINE}
 ✨ *${bold("Total Commands")}* ➜ ${cat.cmds.length}
${LINE}

╭━━━〔 ${cat.emoji} *${bold(cat.title)}* 〕━━━⊷
${rows}
╰━━━━━━━━━━━━━━━━━━━⊷

🔙 *${bold("Back")}* ➜ \`${p}menu\`

> ${BRAND}`;
};

// ── Sender (video + optional audio, same behaviour as before) ───────────────
const contextInfo = () => ({
  forwardingScore: 999,
  isForwarded: true,
  forwardedNewsletterMessageInfo: {
    newsletterJid: config.WA_CHANNEL_JID,
    newsletterName: config.BOT_NAME,
    serverMessageId: -1,
  },
});

Module({
  command: "menu",
  aliases: ["listmenu", "list"],
  package: "general",
  description: `Main ${BRAND} menu`,
})(async (message) => {
  const videoUrl = config.MENU_VIDEO_URL;
  const audioUrl = config.MENU_AUDIO_URL;
  const text = mainMenu(message);
  const ci = contextInfo();

  try {
    await message.react("📜");
    if (!videoUrl) throw new Error("MENU_VIDEO_URL is not configured");

    // gifPlayback stays false so the menu remains a real MP4 with its audio.
    await message.conn.sendMessage(
      message.from,
      { video: { url: videoUrl }, mimetype: "video/mp4", gifPlayback: false, caption: text, contextInfo: ci },
      { quoted: message.gift }
    );

    if (audioUrl) {
      await new Promise((r) => setTimeout(r, 1200));
      await message.conn.sendMessage(
        message.from,
        { audio: { url: audioUrl }, mimetype: "audio/mp4", ptt: false },
        { quoted: message.gift }
      );
    }
  } catch (err) {
    console.error("[menu] failed:", err?.message || err);
    try {
      await message.conn.sendMessage(
        message.from,
        { text, contextInfo: ci },
        { quoted: message.gift }
      );
    } catch (e) {
      console.error("[menu] fallback failed:", e?.message || e);
    }
  }
});

// ── One command per category: .ownermenu, .animemenu, ... ───────────────────
for (const cat of CATEGORIES) {
  Module({
    command: cat.command,
    aliases: cat.aliases,
    package: "general",
    description: `${cat.title} commands`,
  })(async (message) => {
    try {
      await message.react(cat.emoji);
      await message.conn.sendMessage(
        message.from,
        { text: categoryMenu(cat), contextInfo: contextInfo() },
        { quoted: message.gift }
      );
    } catch (err) {
      console.error(`[${cat.command}] failed:`, err?.message || err);
    }
  });
}

// ── .allmenu : every category, one after another ────────────────────────────
Module({
  command: "allmenu",
  package: "general",
  description: "Show every menu",
})(async (message) => {
  try {
    await message.react("📖");
    for (const cat of CATEGORIES) {
      await message.conn.sendMessage(
        message.from,
        { text: categoryMenu(cat), contextInfo: contextInfo() },
        { quoted: message.gift }
      );
      await new Promise((r) => setTimeout(r, 700));
    }
  } catch (err) {
    console.error("[allmenu] failed:", err?.message || err);
  }
});

Module({
  command: "alive",
  package: "general",
  description: "Check bot status",
})(async (message) => {
  await message.send(
    `💚 *${bold("DH--K X MD")}* ${bold("is online")}\n\n⏱️ *${bold("Uptime")}* ➜ ${runtime(process.uptime())}\n💾 *${bold("RAM")}* ➜ ${(process.memoryUsage().rss / 1024 / 1024).toFixed(1)} MB\n\n> Powered by ${BRAND}`
  );
});
