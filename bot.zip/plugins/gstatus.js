import { Module } from "../lib/plugins.js";

Module({
  command: "groupstatus",
  aliases: ["poststatus", "statuspost"],
  package: "group",
  description: "Post text or media to WhatsApp Status",
})(async (message, match) => {
  try {
    const caption = (match || "").trim();
    const pushname = message.pushName || "User";
    const time = new Date().toLocaleString();

    // ── TEXT STATUS ──────────────────────────────────────────────────────────
    if (!message.quoted && caption) {
      await message.conn.sendMessage("status@broadcast", {
        text: `╭━━〔 𝐃𝐇--𝐊 𝐗 𝐌𝐃 〕━━⬣
┃ 👤 User : ${pushname}
┃ ⏰ Time : ${time}
┃
┃ 💬 Message:
┃ ${caption}
╰━━━━━━━━━━━━━━━━⬣`,
      });

      return message.send("✅ Text status posted successfully.");
    }

    if (!message.quoted) {
      return message.send(
        "❌ Reply to an image, video, audio, or sticker.\n\nExample:\n`.groupstatus Hello World`"
      );
    }

    const quoted = message.quoted;
    const media = await quoted.download();

    if (!media) {
      return message.send("❌ Failed to download media.");
    }

    // ── IMAGE ────────────────────────────────────────────────────────────────
    if (quoted.type === "imageMessage" || quoted.imageMessage) {
      await message.conn.sendMessage("status@broadcast", {
        image: media,
        caption: `📸 𝐃𝐇--𝐊 𝐗 𝐌𝐃

👤 Posted By: ${pushname}
🕒 ${time}

${caption || "No Caption"}`,
      });
      return message.send("✅ Image status posted.");
    }

    // ── VIDEO ────────────────────────────────────────────────────────────────
    if (quoted.type === "videoMessage" || quoted.videoMessage) {
      await message.conn.sendMessage("status@broadcast", {
        video: media,
        caption: `🎥 𝐃𝐇--𝐊 𝐗 𝐌𝐃

👤 Posted By: ${pushname}
🕒 ${time}

${caption || "No Caption"}`,
      });
      return message.send("✅ Video status posted.");
    }

    // ── AUDIO ────────────────────────────────────────────────────────────────
    if (quoted.type === "audioMessage" || quoted.audioMessage) {
      await message.conn.sendMessage("status@broadcast", {
        audio: media,
        mimetype: "audio/mp4",
        ptt: false,
      });
      return message.send("✅ Audio status posted.");
    }

    // ── STICKER ──────────────────────────────────────────────────────────────
    if (quoted.type === "stickerMessage" || quoted.stickerMessage) {
      await message.conn.sendMessage("status@broadcast", {
        sticker: media,
      });
      return message.send("✅ Sticker status posted.");
    }

    return message.send("❌ Unsupported media type.");
  } catch (err) {
    console.error("GROUPSTATUS ERROR:", err);
    return message.send(
      `❌ 𝐃𝐇--𝐊 𝐗 𝐌𝐃 STATUS ERROR\n\n${err?.message || err}`
    );
  }
});