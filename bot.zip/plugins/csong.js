import axios from "axios";
import yts from "yt-search";
import fs from "fs";
import path from "path";
import os from "os";
import ffmpeg from "fluent-ffmpeg";
import ffmpegPath from "ffmpeg-static";
import { Module } from "../lib/plugins.js";
import { fetchSongAudio } from "../lib/songFetch.mjs";
import smallcapsPkg from "../lib/smallcaps.js";

ffmpeg.setFfmpegPath(ffmpegPath);

const { smallcaps } = smallcapsPkg;
const M = (text) => smallcaps(String(text));
const B = (text) => `*${M(text)}*`;

const generateWaveform = () =>
  Array.from({ length: 100 }, () => Math.floor(Math.random() * 101));

const formatChannelFallback = (raw) => {
  if (!raw) return "WhatsApp Channel";
  return raw.replace(/@newsletter$/, "");
};

const resolveChannel = async (input, message) => {
  input = input.trim();

  try {
    const url = new URL(input);
    if (url.pathname.startsWith("/channel/")) {
      const code = url.pathname.split("/channel/")[1];
      const meta = await message.conn.newsletterMetadata("invite", code, "GUEST");
      if (!meta?.id) return null;
      return { jid: meta.id, name: meta.name || formatChannelFallback(meta.id) };
    }
  } catch (_) {}

  if (input.includes("@newsletter")) {
    try {
      const meta = await message.conn.newsletterMetadata("jid", input, "GUEST");
      return { jid: input, name: meta?.name || formatChannelFallback(input) };
    } catch (_) {
      return { jid: input, name: formatChannelFallback(input) };
    }
  }

  return null;
};

const isYouTubeUrl = (str) =>
  /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/.+/.test(str.trim());

const toVoiceNote = async (audioUrl, knownSeconds) => {
  const inFile = path.join(os.tmpdir(), `csong_in_${Date.now()}.mp3`);
  const outFile = path.join(os.tmpdir(), `csong_out_${Date.now()}.ogg`);

  console.time("[CSONG TIMING]   -> fetch mp3 bytes");
  const { data } = await axios.get(audioUrl, {
    responseType: "arraybuffer",
    timeout: 30000,
  });
  fs.writeFileSync(inFile, Buffer.from(data));
  console.timeEnd("[CSONG TIMING]   -> fetch mp3 bytes");

  console.time("[CSONG TIMING]   -> ffmpeg transcode");
  await new Promise((resolve, reject) => {
    ffmpeg(inFile)
      .audioCodec("libopus")
      .audioBitrate("48k")
      .noVideo()
      .format("ogg")
      .on("error", reject)
      .on("end", resolve)
      .save(outFile);
  });
  console.timeEnd("[CSONG TIMING]   -> ffmpeg transcode");

  let duration = knownSeconds && knownSeconds > 0 ? Math.ceil(knownSeconds) : null;

  if (!duration) {
    console.time("[CSONG TIMING]   -> ffprobe (output, fallback)");
    duration = await new Promise((resolve) => {
      ffmpeg.ffprobe(outFile, (err, meta) => {
        const d = meta?.format?.duration;
        resolve(!err && d ? Math.ceil(d) : null);
      });
    });
    console.timeEnd("[CSONG TIMING]   -> ffprobe (output, fallback)");
  }

  if (!duration) {
    const bytes = fs.statSync(outFile).size;
    duration = Math.max(1, Math.round((bytes * 8) / 64000));
    console.warn("[CSONG] Falling back to size-based duration estimate:", duration);
  }

  try { fs.unlinkSync(inFile); } catch {}

  return { outFile, duration };
};

Module({
  command: "csong",
  package: "youtube",
  description: "Download song → voice note → send to channel",
  usage: ".csong <song name / yt link> , <channel link>",
})(async (message, match) => {
  const jid = message.from;
  let statusMsg = null;

  const setStatus = async (text) => {
    if (statusMsg?.key) {
      try {
        const edited = await message.conn.sendMessage(jid, {
          text: B(text),
          edit: statusMsg.key,
        });
        if (edited?.key) {
          statusMsg = edited;
          return statusMsg;
        }
      } catch (_) {}
    }
    statusMsg = await message.conn.sendMessage(
      jid,
      { text: B(text) },
      { quoted: message.raw }
    );
    return statusMsg;
  };

  try {
    if (!match) {
      return message.send(
        `${B("usage")}\n\n.csong love nwantiti , https://whatsapp.com/channel/xxx`
      );
    }

    const lastComma = match.lastIndexOf(",");
    if (lastComma === -1) {
      return message.send(
        `${B("use a comma to separate the song and the channel link")}\n\n${B("example")}:\n.csong song name , channel link`
      );
    }

    const songInput = match.slice(0, lastComma).trim();
    const channelInput = match.slice(lastComma + 1).trim();

    if (!songInput) return message.send(B("enter a song name or youtube link"));
    if (!channelInput) return message.send(B("enter a channel link"));

    await message.react("🔍");

    const channel = await resolveChannel(channelInput, message);
    if (!channel) {
      return message.send(B("invalid channel link"));
    }

    console.time("[CSONG TIMING] search");
    let video;
    if (isYouTubeUrl(songInput)) {
      const videoId = songInput.match(/(?:v=|youtu\.be\/)([^&?/]+)/)?.[1] || "";
      const res = await yts({ videoId });
      if (res?.title) {
        video = {
          title: res.title,
          author: { name: res.author?.name || "Unknown" },
          timestamp: res.timestamp || "?",
          url: songInput,
          seconds: res.seconds || res.duration?.seconds || null,
        };
      } else {
        video = {
          title: "Unknown Title",
          author: { name: "Unknown" },
          timestamp: "?",
          url: songInput,
          seconds: null,
        };
      }
    } else {
      const res = await yts(songInput);
      if (!res.videos || res.videos.length === 0) {
        return message.send(B("song not found"));
      }
      video = res.videos[0];
      video.seconds = video.seconds || video.duration?.seconds || null;
    }
    console.timeEnd("[CSONG TIMING] search");

    await message.react("⬇️");

    await setStatus(`sending song to channel\n\nsong : ${video.title}`);

    console.time("[CSONG TIMING] song lookup (fallback chain)");
    let audioUrl;
    try {
      ({ audioUrl } = await fetchSongAudio(video.url, { timeout: 30000 }));
    } catch (lookupErr) {
      console.timeEnd("[CSONG TIMING] song lookup (fallback chain)");
      console.error("[CSONG ERROR] all providers failed:", lookupErr.message);
      return setStatus("audio download failed — all song sources are down, try again later");
    }
    console.timeEnd("[CSONG TIMING] song lookup (fallback chain)");

    await message.react("🎙️");

    console.time("[CSONG TIMING] download+transcode to voice note");
    const { outFile, duration } = await toVoiceNote(audioUrl, video.seconds);
    console.timeEnd("[CSONG TIMING] download+transcode to voice note");
    const waveform = generateWaveform();

    await message.react("📤");

    console.time("[CSONG TIMING] upload to channel");
    let sendResult;
    try {
      sendResult = await message.conn.sendMessage(channel.jid, {
        audio: { url: outFile },
        mimetype: "audio/ogg; codecs=opus",
        ptt: true,
        seconds: duration,
        waveform: waveform,
        contextInfo: {
          forwardingScore: 0,
          isForwarded: false,
        },
      });
    } catch (audioErr) {
      console.error("[CSONG ERROR] audio send to newsletter failed:", audioErr);
      try { fs.unlinkSync(outFile); } catch {}
      return setStatus(
        `audio failed to deliver to the channel: ${audioErr.message}\n\ncheck whether this account is the owner or admin of that channel — admin rights are required to post media on a newsletter`
      );
    }
    console.timeEnd("[CSONG TIMING] upload to channel");
    try { fs.unlinkSync(outFile); } catch {}

    if (!sendResult?.key?.id) {
      console.log(
        "[CSONG] audio sendMessage returned no message key — likely silently rejected by WhatsApp:",
        sendResult
      );
      return setStatus(
        "no confirmation received from whatsapp — the account may not be an admin or owner of the channel, or the baileys version is outdated"
      );
    }

    await message.react("✅");
    await setStatus(
      `song sended successfully ✅\nchannel : ${channel.name}\nsong : ${video.title}`
    );
  } catch (err) {
    console.error("[CSONG ERROR]", err);
    if (err.code === "ECONNABORTED") {
      await setStatus("server timeout, try again");
    } else {
      const reason =
        err?.response?.data?.message ||
        err?.response?.data?.error ||
        err?.message ||
        (typeof err === "string" ? err : null) ||
        (err ? JSON.stringify(err).slice(0, 200) : "unknown error");
      await setStatus(`csong failed: ${reason}`);
    }
  }
});