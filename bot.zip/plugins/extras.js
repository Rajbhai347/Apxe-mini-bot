// plugins/extras.js — commands that were listed in .menu but had no handler:
// tts, apk, gitclone, mega, fullpp, fullgcpp, getgcpp
import axios from "axios";
import { Module } from "../lib/plugins.js";

const MAX_BYTES = 100 * 1024 * 1024; // 100 MB WhatsApp-friendly limit
const UA = { "User-Agent": "Mozilla/5.0" };
const P = () => process.env.PREFIX || ".";

const isOwner = (m) => !!(m.isFromMe || m.isfromMe);
const jidOf = (id) => `${String(id || "").split(":")[0].split("@")[0]}@s.whatsapp.net`;

async function sendDocument(message, buffer, fileName, mimetype, caption = "") {
  return message.conn.sendMessage(
    message.from,
    { document: buffer, fileName, mimetype, caption },
    { quoted: message.raw || undefined }
  );
}

async function getImageBuffer(message, match) {
  if (match && /^https?:\/\//i.test(match.trim())) {
    const res = await axios.get(match.trim(), { responseType: "arraybuffer", timeout: 30000, headers: UA });
    return Buffer.from(res.data);
  }
  if (message.type === "imageMessage") return await message.download();
  if (message.quoted?.type === "imageMessage") return await message.quoted.download();
  return null;
}

// ───────────────────────────── TTS ─────────────────────────────
Module({
  command: "tts",
  package: "utility",
  description: "Text to speech — .tts [lang] <text> (e.g. .tts bn আমি ভালো আছি)",
})(async (message, match) => {
  try {
    let text = String(match || "").trim();
    let lang = "en";
    const m = text.match(/^([a-z]{2}(?:-[A-Za-z]{2})?)\s+([\s\S]+)$/);
    if (m) { lang = m[1]; text = m[2].trim(); }
    if (!text) text = String(message.quoted?.text || message.quoted?.body || "").trim();
    if (!text) return message.send(`Usage: ${P()}tts [lang] <text>\nExample: ${P()}tts bn আমি ভালো আছি`);
    text = text.slice(0, 200);

    await message.react("🎙️");
    const res = await axios.get("https://translate.google.com/translate_tts", {
      params: { ie: "UTF-8", q: text, tl: lang, client: "tw-ob" },
      responseType: "arraybuffer",
      timeout: 30000,
      headers: UA,
    });
    await message.conn.sendMessage(
      message.from,
      { audio: Buffer.from(res.data), mimetype: "audio/mpeg", ptt: true },
      { quoted: message.raw || undefined }
    );
    await message.react("✅");
  } catch (e) {
    console.error("[tts]", e?.message || e);
    await message.react("❌").catch(() => {});
    return message.send(`❌ TTS failed: ${e?.message || e}`);
  }
});

// ───────────────────────────── APK ─────────────────────────────
Module({
  command: "apk",
  package: "downloader",
  description: "Download an Android app (APK) — .apk <app name>",
})(async (message, match) => {
  try {
    const q = String(match || "").trim();
    if (!q) return message.send(`Usage: ${P()}apk <app name>`);
    await message.react("🔎");

    const { data } = await axios.get("https://ws75.aptoide.com/api/7/apps/search", {
      params: { query: q, limit: 1 },
      timeout: 30000,
      headers: UA,
    });
    const app = data?.datalist?.list?.[0];
    const url = app?.file?.path || app?.file?.path_alt;
    if (!app || !url) {
      await message.react("❌");
      return message.send("❌ App not found.");
    }
    const size = Number(app.file?.filesize || app.size || 0);
    if (size > MAX_BYTES) return message.send(`❌ APK is too large (${(size / 1048576).toFixed(0)} MB).`);

    await message.react("⬇️");
    const res = await axios.get(url, { responseType: "arraybuffer", timeout: 180000, headers: UA, maxContentLength: MAX_BYTES });
    const safe = String(app.name || "app").replace(/[\\/:*?"<>|]/g, "_");
    await sendDocument(
      message,
      Buffer.from(res.data),
      `${safe}.apk`,
      "application/vnd.android.package-archive",
      `📱 *${app.name}*\n📦 ${app.package || ""}\n🔖 v${app.file?.vername || "?"}`
    );
    await message.react("✅");
  } catch (e) {
    console.error("[apk]", e?.message || e);
    await message.react("❌").catch(() => {});
    return message.send(`❌ APK download failed: ${e?.message || e}`);
  }
});

// ─────────────────────────── GITCLONE ──────────────────────────
Module({
  command: "gitclone",
  package: "downloader",
  description: "Download a GitHub repository as ZIP — .gitclone <repo url>",
})(async (message, match) => {
  try {
    const link = String(match || "").trim();
    const m = link.match(/github\.com\/([^/\s]+)\/([^/\s#?]+)/i);
    if (!m) return message.send(`Usage: ${P()}gitclone https://github.com/user/repo`);
    const owner = m[1];
    const repo = m[2].replace(/\.git$/i, "");

    await message.react("⬇️");
    const res = await axios.get(`https://api.github.com/repos/${owner}/${repo}/zipball`, {
      responseType: "arraybuffer",
      timeout: 120000,
      headers: UA,
      maxRedirects: 5,
      maxContentLength: MAX_BYTES,
    });
    await sendDocument(message, Buffer.from(res.data), `${repo}.zip`, "application/zip", `📦 ${owner}/${repo}`);
    await message.react("✅");
  } catch (e) {
    console.error("[gitclone]", e?.message || e);
    await message.react("❌").catch(() => {});
    const notFound = e?.response?.status === 404;
    return message.send(notFound ? "❌ Repository not found (or private)." : `❌ Gitclone failed: ${e?.message || e}`);
  }
});

// ───────────────────────────── MEGA ────────────────────────────
Module({
  command: "mega",
  package: "downloader",
  description: "Download a file from mega.nz — .mega <link>",
})(async (message, match) => {
  try {
    const link = String(match || "").trim();
    if (!/^https?:\/\/mega\.(nz|io)\//i.test(link)) return message.send(`Usage: ${P()}mega https://mega.nz/file/...`);

    let File;
    try {
      ({ File } = await import("megajs"));
    } catch {
      return message.send("❌ Mega support needs the *megajs* package. Run `npm install` (it is listed in package.json) and restart.");
    }

    await message.react("⬇️");
    const file = File.fromURL(link);
    await file.loadAttributes();
    if (file.size > MAX_BYTES) return message.send(`❌ File is too large (${(file.size / 1048576).toFixed(0)} MB, max 100 MB).`);
    const buffer = await file.downloadBuffer();
    await sendDocument(message, buffer, file.name || "mega_file", "application/octet-stream", `📁 ${file.name || ""}`);
    await message.react("✅");
  } catch (e) {
    console.error("[mega]", e?.message || e);
    await message.react("❌").catch(() => {});
    return message.send(`❌ Mega download failed: ${e?.message || e}`);
  }
});

// ─────────────────────── PROFILE PICTURES ──────────────────────
Module({
  command: "fullpp",
  package: "owner",
  description: "Set the bot's profile picture — reply to an image (or send with caption / URL)",
})(async (message, match) => {
  try {
    if (!isOwner(message)) return message.send("❌ Owner only.");
    const buf = await getImageBuffer(message, match);
    if (!buf) return message.send("❌ Reply to an image (or send an image with the command, or give a URL).");
    await message.react("⏳");
    await message.setPp(jidOf(message.conn.user?.id || message.conn.user?.jid), buf);
    await message.react("✅");
    return message.send("✅ Profile picture updated.");
  } catch (e) {
    console.error("[fullpp]", e?.message || e);
    await message.react("❌").catch(() => {});
    return message.send(`❌ Failed to update profile picture: ${e?.message || e}`);
  }
});

Module({
  command: "fullgcpp",
  package: "group",
  description: "Set the group's profile picture — reply to an image",
})(async (message, match) => {
  try {
    if (!message.isGroup) return message.send("❌ This command works only in groups.");
    await message.loadGroupInfo();
    if (!(message.isAdmin || isOwner(message))) return message.send("❌ Only group admins can use this command.");
    if (!message.isBotAdmin) return message.send("❌ Please make the bot an admin first.");
    const buf = await getImageBuffer(message, match);
    if (!buf) return message.send("❌ Reply to an image (or send an image with the command, or give a URL).");
    await message.react("⏳");
    await message.setPp(message.from, buf);
    await message.react("✅");
    return message.send("✅ Group picture updated.");
  } catch (e) {
    console.error("[fullgcpp]", e?.message || e);
    await message.react("❌").catch(() => {});
    return message.send(`❌ Failed to update group picture: ${e?.message || e}`);
  }
});

Module({
  command: "getgcpp",
  package: "group",
  description: "Get the group's profile picture",
})(async (message) => {
  try {
    if (!message.isGroup) return message.send("❌ This command works only in groups.");
    await message.react("⏳");
    const url = await message.conn.profilePictureUrl(message.from, "image").catch(() => null);
    if (!url) {
      await message.react("ℹ️");
      return message.send("ℹ️ This group has no profile picture.");
    }
    await message.conn.sendMessage(
      message.from,
      { image: { url }, caption: "📷 Group profile picture" },
      { quoted: message.raw || undefined }
    );
    await message.react("✅");
  } catch (e) {
    console.error("[getgcpp]", e?.message || e);
    await message.react("❌").catch(() => {});
    return message.send("❌ Failed to get group picture.");
  }
});
