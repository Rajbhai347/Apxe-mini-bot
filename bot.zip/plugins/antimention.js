// plugins/antimention.js — deletes "group status mention" messages (ESM version, uses the Module API)
import { Module } from "../lib/plugins.js";
import { db } from "../lib/client.js";

const botNumber = (conn) =>
  String(conn?.user?.id || conn?.user?.jid || "bot").split("@")[0].split(":")[0];
const key = (jid, part) => `antimention:${jid}:${part}`;
const PREFIX = () => process.env.PREFIX || ".";

async function ensureGroupAdmin(message) {
  if (!message?.isGroup) {
    await message.send("❌ This command works only in groups.");
    return false;
  }
  await message.loadGroupInfo();
  if (!(message.isAdmin || message.isFromMe || message.isfromMe)) {
    await message.send("❌ Only group admins/owner can use this command.");
    return false;
  }
  return true;
}

function isGroupStatusMention(message) {
  const msg = message?.raw?.message || message?.message || {};
  return !!(
    msg.groupStatusMentionMessage ||
    msg.extendedTextMessage?.contextInfo?.groupStatusMentionMessage ||
    msg.messageContextInfo?.groupStatusMentionMessage
  );
}

Module({
  command: "antimention",
  aliases: ["antigmention"],
  package: "group",
  description: "Delete group status mentions (on/off, kick/warn/delete mode)",
})(async (message, match) => {
  try {
    if (!(await ensureGroupAdmin(message))) return;
    const sid = botNumber(message.conn);
    const enabledKey = key(message.from, "enabled");
    const modeKey = key(message.from, "mode");
    const msgKey = key(message.from, "msg");
    const raw = String(match || "").trim();
    const [sub = "", ...rest] = raw.split(/\s+/);
    const cmd = sub.toLowerCase();
    const p = PREFIX();

    if (!cmd) {
      const enabled = db.get(sid, enabledKey, false) === true;
      const mode = String(db.get(sid, modeKey, "delete") || "delete").toUpperCase();
      const custom = db.get(sid, msgKey, "") ? "✅ set" : "❌ not set";
      return message.send(
        `╭━━〔 🏷️ 𝐀𝐍𝐓𝐈𝐌𝐄𝐍𝐓𝐈𝐎𝐍 〕━━┈⊷\n┃✧ Status : ${enabled ? "✅ ON" : "❌ OFF"}\n┃✧ Mode   : ${mode}\n┃✧ Message: ${custom}\n╰━━━━━━━━━━━━━━━━━━⊷\n\nUse:\n${p}antimention on\n${p}antimention off\n${p}antimention kick\n${p}antimention warn\n${p}antimention delete\n${p}antimention setmsg <text>\n${p}antimention delmsg`
      );
    }

    if (cmd === "on") {
      db.setHot(sid, enabledKey, true);
      if (!db.get(sid, modeKey, null)) db.setHot(sid, modeKey, "delete");
      await message.react("✅");
      return message.send("✅ *AntiMention enabled.*");
    }
    if (cmd === "off") {
      db.setHot(sid, enabledKey, false);
      await message.react("❌");
      return message.send("❌ *AntiMention disabled.*");
    }
    // accept both ".antimention kick" and ".antimention set kick"
    const modeArg = cmd === "set" ? String(rest[0] || "").toLowerCase() : cmd;
    if (["kick", "remove", "warn", "delete"].includes(modeArg)) {
      const mode = modeArg === "remove" ? "kick" : modeArg;
      db.setHot(sid, modeKey, mode);
      db.setHot(sid, enabledKey, true);
      await message.react("🏷️");
      return message.send(`✅ AntiMention mode: *${mode.toUpperCase()}*`);
    }
    if (cmd === "setmsg") {
      const text = rest.join(" ").trim();
      if (!text) return message.send(`❌ Example: ${p}antimention setmsg @user please don't mention the group in status!`);
      db.setHot(sid, msgKey, text);
      return message.send("✅ Custom AntiMention message saved.");
    }
    if (cmd === "delmsg") {
      db.setHot(sid, msgKey, "");
      return message.send("🗑️ Custom AntiMention message removed.");
    }
    return message.send(`Usage: ${p}antimention on/off/kick/warn/delete/setmsg/delmsg`);
  } catch (e) {
    console.error("[antimention command]", e);
    await message.react("❌").catch(() => {});
    return message.send(`❌ AntiMention error: ${e?.message || e}`);
  }
});

// Enforcement: must be "message" (not "text") because status mentions have no text body.
Module({ on: "message", package: "group", description: "AntiMention enforcement" })(async (message) => {
  try {
    if (!message?.isGroup || message.isFromMe || message.isfromMe) return;
    if (!isGroupStatusMention(message)) return;

    const sid = botNumber(message.conn);
    if (db.get(sid, key(message.from, "enabled"), false) !== true) return;

    await message.loadGroupInfo();
    if (message.isAdmin) return;
    if (!message.isBotAdmin) return;

    const sender = message.sender || message.key?.participant || message.key?.participantAlt;
    if (!sender) return;
    const number = String(sender).split("@")[0].split(":")[0];
    const tag = `@${number}`;
    const mode = String(db.get(sid, key(message.from, "mode"), "delete") || "delete").toLowerCase();
    const customRaw = String(db.get(sid, key(message.from, "msg"), "") || "");
    const custom = customRaw
      ? /@user/i.test(customRaw) ? customRaw.replace(/@user/gi, tag) : `${tag} ${customRaw}`
      : null;

    try {
      await message.conn.sendMessage(message.from, { delete: message.key });
    } catch (e) {
      console.warn("[antimention] delete failed:", e?.message || e);
    }
    if (mode === "delete") return;

    if (mode === "warn") {
      const warnKey = key(message.from, `warn:${number}`);
      const warns = (Number(db.get(sid, warnKey, 0)) || 0) + 1;
      if (warns < 3) {
        db.setHot(sid, warnKey, warns);
        await message.send(custom || `⚠️ ${tag}, don't mention the group in status (${warns}/3)`, { mentions: [sender] });
        return;
      }
      db.setHot(sid, warnKey, 0);
      await message.send(custom || `🚫 ${tag} reached 3 warnings and will be removed.`, { mentions: [sender] });
    } else {
      await message.send(custom || `🚫 ${tag} mentioned the group in status and will be removed.`, { mentions: [sender] });
    }

    try {
      await message.conn.groupParticipantsUpdate(message.from, [sender], "remove");
    } catch (e) {
      console.error("[antimention] kick failed:", e?.message || e);
    }
  } catch (e) {
    console.error("[antimention enforcement]", e);
  }
});
