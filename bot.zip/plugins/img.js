import axios from "axios";
import { Module } from '../lib/plugins.js';

Module({
  command: "img",
  package: "search",
  description: "Search and download original quality images from Google",
})(async (message, match) => {
  if (!match) {
    return await message.sendReply(
      "_Please provide a search keyword_\n*Example:* .img anime\n.img anime,5"
    );
  }

  let [text, count] = match.split(/[;,|]/);
  if (!text) text = match.trim();

  count = parseInt(count) || 5;
  if (count > 10) count = 10;

  await message.send(`🔍 Searching Google Images for *${text}*...`);

  try {
    const images = await searchGoogleImagesOriginal(text);

    if (!images || images.length === 0) {
      return await message.sendReply(
        `❌ No images found for *"${text}"*. Try another search.`
      );
    }

    const max = Math.min(images.length, count);

    for (let i = 0; i < max; i++) {
      try {
        await message.conn.sendMessage(message.from, {
          image: { url: images[i] },
          caption: `🖼️ *Search:* ${text}\n📊 *Image ${i + 1}/${max}*\n> © PRIME SOUMYA`,
        });
        await new Promise((resolve) => setTimeout(resolve, 2000));
      } catch (sendErr) {
        console.error(`Failed to send image ${i + 1}:`, sendErr.message);
      }
    }
  } catch (err) {
    console.error("Google image search error:", err);
    return await message.sendReply(
      `❌ *Error while fetching images. Please try again.*`
    );
  }
});

async function searchGoogleImagesOriginal(query) {
  try {
    const encodedQuery = encodeURIComponent(query);
    const url = `https://www.google.com/search?q=${encodedQuery}&tbm=isch&tbs=isz:l&hl=en`;

    const response = await axios.get(url, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        Accept:
          "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
        Connection: "keep-alive",
        "Upgrade-Insecure-Requests": "1",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Cache-Control": "max-age=0",
      },
      timeout: 15000,
    });

    const seen = new Set();
    const images = [];

    const addImage = (url) => {
      if (url && !seen.has(url)) {
        seen.add(url);
        images.push(url);
      }
    };

    const html = response.data;

    // Primary: "ou" = original image URL (no extension filter — many valid URLs lack extensions)
    const ouRegex = /"ou":"(https?:\/\/[^"]+?)"/g;
    let match;
    while ((match = ouRegex.exec(html)) !== null) {
      let originalUrl = match[1]
        .replace(/\\u003d/g, "=")
        .replace(/\\u0026/g, "&")
        .replace(/\\u002F/g, "/")
        .replace(/\\/g, "");
      // Skip Google's own thumbnail/tracking domains
      if (!originalUrl.includes("encrypted-tbn") && !originalUrl.includes("gstatic.com")) {
        addImage(originalUrl);
      }
    }

    // Secondary: metadata JSON arrays ["url", width, height] — require width OR height >= 800
    const metadataRegex =
      /\["(https?:\/\/[^"]+?\.(?:jpg|jpeg|png|gif|webp))","(\d+)","(\d+)"\]/g;
    let metaMatch;
    while ((metaMatch = metadataRegex.exec(html)) !== null) {
      const width = parseInt(metaMatch[2]);
      const height = parseInt(metaMatch[3]);
      if ((width >= 800 || height >= 800) && !metaMatch[1].includes("gstatic.com")) {
        addImage(metaMatch[1]);
      }
    }

    // Tertiary: AF_initDataCallback arrays ["url", width, height] — require width OR height >= 500
    const dataRegex = /\["(https?:\/\/[^"]+?)",(\d+),(\d+)\]/g;
    let dataMatch;
    while ((dataMatch = dataRegex.exec(html)) !== null) {
      const imgUrl = dataMatch[1];
      const width = parseInt(dataMatch[2]);
      const height = parseInt(dataMatch[3]);
      if (
        imgUrl.match(/\.(jpg|jpeg|png|gif|webp)(\?|$)/i) &&
        (width >= 500 || height >= 500) &&
        !imgUrl.includes("encrypted-tbn") &&
        !imgUrl.includes("gstatic.com")
      ) {
        addImage(imgUrl);
      }
    }

    console.log(`Found ${images.length} original quality Google images for: ${query}`);
    return images.slice(0, 20);
  } catch (error) {
    console.error("Google scraping error:", error.message);
    throw new Error("Failed to fetch Google images");
  }
}