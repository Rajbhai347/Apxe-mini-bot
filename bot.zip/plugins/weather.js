import { Module } from '../lib/plugins.js';
import axios from 'axios';

Module({
  command: 'weather',
  package: 'info',
  aliases: ['w', 'wttr'],
  description: 'Weather forecast'
})(async (message, match) => {
  let query = match?.trim() || 'Johannesburg';

  if (!query) {
    return message.send("*Please provide a city name*");
  }

  await message.react('⏳');

  try {
    const response = await axios.get(
      `https://wttr.in/${encodeURIComponent(query)}?format=%c+%t+%C+%h+%w`,
      { timeout: 10000 }
    );

    let raw = response.data.trim();

    if (!raw || raw.includes("404") || raw.length < 10) {
      await message.react('❌');
      return message.send("❌ Location not found! Please check the spelling.");
    }

    raw = raw.replace(/↑/g, " ↑");
    const parts = raw.split(/\s+/).filter(Boolean);

    const weatherReport = `🌤️ ＷＥＡＴＨＥＲ  ＲＥＰＯＲＴ\n\n` +
      `> *Location:* ${query.toUpperCase()}\n` +
      `> *Condition:* ${parts[2] || "N/A"}\n` +
      `> *Temperature:* ${parts[1] || "N/A"}\n` +
      `> *Humidity:* ${parts[3] || "N/A"}\n` +
      `> *Wind:* ${parts[4] || ""} ${parts[5] || ""}`.trim();

    await message.send(weatherReport);
    await message.react('✅');

  } catch (err) {
    console.error('Weather Error:', err);
    await message.react('❌');
    await message.send("*Failed to fetch weather. Try again later.*");
  }
});