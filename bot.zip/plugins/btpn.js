import { Module } from "../lib/plugins.js";

Module({
  command: "btpn",
  package: "mics",
  description: "Replies with the bot latency",
})(async (message) => {
  const start = Date.now();

  const emojis = [
    "⛅","👻","⛄","👀","🪁","🪃","🎳","🎀","🌸","🍥","🍓","🍡","💗","🦋","💫",
    "💀","☁️","🌨️","🌧️","🌦️","🌥️","⚡","🌟","🎐","🏖️","🌊","🐚","🍒","🍇",
    "🍉","🌻","🎢","🚀","🍫","💎","🌋","🏔️","🌙","🪐","🌲","🍃","🍂","🍁",
    "🍄","🌿","🐞","🐍","🕊️","🎃","🎡","🥂","🗿","⛩️"
  ];

  const emoji = emojis[Math.floor(Math.random() * emojis.length)];
  await message.react(emoji);

  const latency = Date.now() - start;

  await message.conn.sendMessage(
    message.from,
    {
      text: `*${emoji} } 𝗣𝗡𝗚👀: ${latency} ๓Ş*`,
      footer: "⦏𝐍𝐎 𝐋𝐎𝐕𝐄⦐",
      buttons: [
        {
          buttonId: ".alive",
          buttonText: { displayText: "✅ Alive" },
          type: 1,
        },
        {
          buttonId: ".owner",
          buttonText: { displayText: "👑 Owner" },
          type: 1,
        },
      ],
      headerType: 1,
      contextInfo: {
        mentionedJid: [message.sender],
      },
    },
    { quoted: message.gift }
  );
});