import { Module } from "../lib/plugins.js";
import config from "../config.js";
import { getTheme } from "../Themes/themes.js";
import { db } from "../lib/client.js";
const theme = getTheme();

// helper to resolve bot number safely
function resolveBotNumber(conn) {
  // prefer conn.id if provided, else fallback to conn.user.id split
  if (!conn) return null;
  if (conn.id) return String(conn.id);
  if (conn.user && conn.user.id) return String(conn.user.id).split(":")[0];
  return null;
}

// 🔹 Auto Status Seen
Module({
  command: "autostatus",
  package: "owner",
  description: "Toggle auto view WhatsApp status",
})(async (message, match) => {
  if (!message.isFromMe) return message.send(theme.isfromMe);
  const botNumber = resolveBotNumber(message.conn);
  if (!botNumber) return message.send("❌ Bot number not found.");

  const input = match?.trim().toLowerCase();

  const key = "autostatus_seen"; // hot-key name used in handler

  if (input === "on" || input === "off") {
    await message.react("⏳");
    try {
      if (input === "on") db.setHot(botNumber, key, true);
      else db.delHot(botNumber, key);
      await message.react("✅");
      return await message.send(
        `✅ *Auto status view is now \`${input.toUpperCase()}\`*`
      );
    } catch (e) {
      await message.react("❌");
      return await message.send("❌ *Error updating auto status view*");
    }
  }

  const status = db.get(botNumber, key, false) === true;
  return await message.send(
    `⚙️ *Auto Status View*\n> Status: ${
      status ? "✅ ON" : "❌ OFF"
    }\n\nUse:\n• astatus on\n• astatus off`
  );
});

// 🔹 Auto Typing
Module({
  command: "autotyping",
  package: "owner",
  description: "Toggle auto typing in chats",
})(async (message, match) => {
  if (!message.isFromMe) return message.send(theme.isfromMe);
  const botNumber = resolveBotNumber(message.conn);
  if (!botNumber) return message.send("❌ Bot number not found.");

  const input = match?.trim().toLowerCase();
  const key = "autotyping";

  if (input === "on" || input === "off") {
    await message.react("⏳");
    try {
      if (input === "on") db.setHot(botNumber, key, true);
      else db.delHot(botNumber, key);
      await message.react("✅");
      return await message.send(
        `✅ *Auto typing is now \`${input.toUpperCase()}\`*`
      );
    } catch (e) {
      await message.react("❌");
      return await message.send("❌ *Error updating auto typing*");
    }
  }

  const status = db.get(botNumber, key, false) === true;
  return await message.send(
    `⚙️ *Auto Typing*\n> Status: ${
      status ? "✅ ON" : "❌ OFF"
    }\n\nUse:\n• autotyping on\n• autotyping off`
  );
});

// 🔹 Auto Recording
Module({
  command: "autorecord",
  package: "owner",
  description: "Toggle auto voice recording in chats",
})(async (message, match) => {
  if (!message.isFromMe) return message.send(theme.isfromMe);
  const botNumber = resolveBotNumber(message.conn);
  if (!botNumber) return message.send("❌ Bot number not found.");

  const input = match?.trim().toLowerCase();
  const key = "autorecord";

  if (input === "on" || input === "off") {
    await message.react("⏳");
    try {
      if (input === "on") db.setHot(botNumber, key, true);
      else db.delHot(botNumber, key);
      await message.react("✅");
      return await message.send(
        `✅ *Auto record is now \`${input.toUpperCase()}\`*`
      );
    } catch (e) {
      await message.react("❌");
      return await message.send("❌ *Error updating auto record*");
    }
  }

  const status = db.get(botNumber, key, false) === true;
  return await message.send(
    `🎤 *Auto Record*\n> Status: ${
      status ? "✅ ON" : "❌ OFF"
    }\n\nUse:\n• autorecord on\n• autorecord off`
  );
});

// 🔹 Auto React to Messages
Module({
  command: "autoreact",
  package: "owner",
  description: "Toggle auto react to messages",
})(async (message, match) => {
  if (!message.isFromMe) return message.send(theme.isfromMe);
  const botNumber = resolveBotNumber(message.conn);
  if (!botNumber) return message.send("❌ Bot number not found.");

  const input = match?.trim().toLowerCase();
  const key = "autoreact";

  if (input === "on" || input === "off") {
    await message.react("⏳");
    try {
      if (input === "on") db.setHot(botNumber, key, true);
      else db.delHot(botNumber, key);
      await message.react("✅");
      return await message.send(
        `✅ *AutoReact is now \`${input.toUpperCase()}\`*`
      );
    } catch (e) {
      await message.react("❌");
      return await message.send("❌ *Error updating AutoReact*");
    }
  }

  const status = db.get(botNumber, key, false) === true;
  return await message.send(
    `⚙️ *AutoReact*\n> Status: ${
      status ? "✅ ON" : "❌ OFF"
    }\n\nUse:\n• autoreact on\n• autoreact off`
  );
});

// 🔹 Anti Call
Module({
  command: "anticall",
  package: "owner",
  description: "Block users who call the bot",
})(async (message, match) => {
  if (!message.isFromMe) return message.send(theme.isfromMe);
  const botNumber = resolveBotNumber(message.conn);
  if (!botNumber) return message.send("❌ Bot number not found.");

  const input = match?.trim().toLowerCase();
  const key = "anticall";

  if (input === "on" || input === "off") {
    await message.react("⏳");
    try {
      if (input === "on") db.setHot(botNumber, key, true);
      else db.delHot(botNumber, key);
      await message.react("✅");
      return await message.send(
        `✅ *AntiCall is now \`${input.toUpperCase()}\`*`
      );
    } catch (e) {
      await message.react("❌");
      return await message.send("❌ *Error updating AntiCall*");
    }
  }

  const status = db.get(botNumber, key, false) === true;
  return await message.send(
    `⚙️ *AntiCall*\n> Status: ${
      status ? "✅ ON" : "❌ OFF"
    }\n\nUse:\n• anticall on\n• anticall off`
  );
});

// 🔹 Auto Read
Module({
  command: "autoread",
  package: "owner",
  description: "Toggle auto read messages",
})(async (message, match) => {
  if (!message.isFromMe) return message.send(theme.isfromMe);
  const botNumber = resolveBotNumber(message.conn);
  if (!botNumber) return message.send("❌ Bot number not found.");

  const input = match?.trim().toLowerCase();

  if (input === "on" || input === "off") {
    await message.react("⏳");
    try {
      if (input === "on") db.setHot(botNumber, key, true);
      else db.delHot(botNumber, key);
      await message.react("✅");
      return await message.send(
        `✅ *AutoRead is now \`${input.toUpperCase()}\`*`
      );
    } catch (e) {
      await message.react("❌");
      return await message.send("❌ *Error updating AutoRead*");
    }
  }

  const status = db.get(botNumber, key, false) === true;
  return await message.send(
    `⚙️ *AutoRead*\n> Status: ${
      status ? "✅ ON" : "❌ OFF"
    }\n\nUse:\n• autoread on\n• autoread off`
  );
});

Module({
  command: "mode",
  package: "owner",
  description: "Toggle bot mode (public / private)",
})(async (message, match) => {
  if (!message.isFromMe) return message.send(theme.isfromMe);

  const botNumber = resolveBotNumber(message.conn);
  if (!botNumber) return message.send("❌ Bot number not found.");

  const input = match?.trim().toLowerCase();
  const key = "mode"; // true = public, false = private

  if (input === "public" || input === "private") {
    await message.react("⏳");
    try {
      if (input === "public") {
        db.setHot(botNumber, key, true);
      } else {
        db.setHot(botNumber, key, false);
      }

      await message.react("✅");
      return message.send(`✅ *Bot mode set to* \`${input.toUpperCase()}\``);
    } catch (err) {
      await message.react("❌");
      return message.send("❌ *Failed to update bot mode*");
    }
  }

  const isPublic = db.get(botNumber, key, true) === true;

  return message.send(
    `⚙️ *Bot Mode*\n` +
      `> Status: ${isPublic ? "🌍 PUBLIC" : "🔒 PRIVATE"}\n\n` +
      `*Usage:*\n` +
      `• mode public\n` +
      `• mode private`
  );
});

Module({
  command: "public",
  package: "owner",
  description: "Set bot mode to public",
})(async (message) => {
  if (!message.isFromMe) return message.send(theme.isfromMe);

  const botNumber = resolveBotNumber(message.conn);
  if (!botNumber) return message.send("❌ Bot number not found.");

  const key = "mode"; // true = public
  await message.react("⏳");

  try {
    db.setHot(botNumber, key, true);
    await message.react("✅");
    return message.send("✅ *Bot mode set to* `PUBLIC`");
  } catch (err) {
    await message.react("❌");
    return message.send("❌ *Failed to update bot mode*");
  }
});

Module({
  command: "private",
  package: "owner",
  description: "Set bot mode to private",
})(async (message) => {
  if (!message.isFromMe) return message.send(theme.isfromMe);

  const botNumber = resolveBotNumber(message.conn);
  if (!botNumber) return message.send("❌ Bot number not found.");

  const key = "mode"; // false = private
  await message.react("⏳");

  try {
    db.setHot(botNumber, key, false);
    await message.react("✅");
    return message.send("✅ *Bot mode set to* `PRIVATE`");
  } catch (err) {
    await message.react("❌");
    return message.send("❌ *Failed to update bot mode*");
  }
});

Module({
  command: "mention",
  package: "owner",
  description: "Toggle auto mention messages",
})(async (message, match) => {
  if (!message.isFromMe) return message.send(theme.isfromMe);
  const botNumber = resolveBotNumber(message.conn);
  if (!botNumber) return message.send("❌ Bot number not found.");
  
  const key = "mention";
  const input = match?.trim().toLowerCase();
  
  if (input === "on" || input === "off") {
    await message.react("⏳");
    try {
      if (input === "on") db.setHot(botNumber, key, true);
      else db.delHot(botNumber, key);
      await message.react("✅");
      return await message.send(
        `✅ *Mention is now \`${input.toUpperCase()}\`*`
      );
    } catch (e) {
      await message.react("❌");
      return await message.send("❌ *Error updating Mention*");
    }
  }
  
  const status = db.get(botNumber, key, false) === true;
  return await message.send(
    `⚙️ *Mention*\n> Status: ${
      status ? "✅ ON" : "❌ OFF"
    }\n\nUse:\n• mention on\n• mention off`
  );
});